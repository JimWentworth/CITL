CITL AI Quick Tips: PowerPoint to Video

Open index.html in any modern web browser. No web server, build process, or
internet connection is required to display the page. External links in the
header and footer require internet access.

Contents
- index.html: standalone webpage
- styles.css: local page styling and responsive layouts
- assets/: official Illinois brand assets, locally bundled brand fonts, and
  tutorial graphics

Brand implementation
- Official University of Illinois Block I and primary wordmark
- Illini Orange #FF5F05 and Illini Blue #13294B as dominant colors
- Montserrat for headings and Source Sans for body copy
- University and unit header hierarchy
- University and CITL footer information
- Keyboard focus styles, skip link, responsive design, reduced-motion support,
  descriptive image text, and semantic page landmarks

Source
Center for Innovation in Teaching & Learning
University of Illinois Urbana-Champaign
https://citl.illinois.edu/
