CITL AI Quick Tips: Image to JSON Context File

Open index.html in any modern web browser. No web server, build process, or
internet connection is required to display the page. External university links
require internet access.

The assets folder contains all fonts and brand graphics used by the page.
Keep index.html, styles.css, and the assets folder together.

Center for Innovation in Teaching & Learning
University of Illinois Urbana-Champaign
https://citl.illinois.edu/
